class Serie {
    constructor(title, description, imgUrl) {
        this.title = title;
        this.description = description;
        this.imgUrl = imgUrl;
    }
}

module.exports = { Serie };
