

const { Router } = require('express');

const commonRoutes = Router();

commonRoutes.get('/', (req, res) => {
    return res.render('home', { name: "OLX DA XURUPITA"});
});

commonRoutes.get('/faq', (req, res) => {
    return res.render('faq');
})

module.exports = { commonRoutes };