

const moviesAndSeries = [
    {
        id: '1',
        title: 'Gotham',
        description: 'Tudo escuro',
        imgUrl: ''
    },
    {
        id: '2',
        title: 'The Last of Us',
        description: 'Mas tem varios',
        imgUrl: ''
    },
    {
        id: '3',
        title: 'The Witcher',
        description: ' e o ataque dos lobinhos',
        imgUrl: 'https://cdn1.epicgames.com/offer/14ee004dadc142faaaece5a6270fb628/EGS_TheWitcher3WildHuntCompleteEdition_CDPROJEKTRED_S1_2560x1440-82eb5cf8f725e329d3194920c0c0b64f'
    },
    {
        id: '4',
        title: 'The walking dead',
        description: ' e ficam tudo parado, as 10 temp',
        imgUrl: ''
    },
    {
        id: '5',
        title: 'Wandinha',
        description: 'Top',
        imgUrl: ''
    },
    {
        id: '6',
        title: 'Reacher',
        description: 'Bem bom segundo Geraldo',
        imgUrl: ''
    },
    {
        id: '7',
        title: 'Titas',
        description: ' mas tudo novinho',
        imgUrl: ''
    },
    {
        id: '8',
        title: 'Black List',
        description: ' ou lista negra',
        imgUrl: ''
    },
    {
        id: '9',
        title: 'The boys',
        description: 'Sangrento',
        imgUrl: ''
    },
    {
        id: '10',
        title: 'The Big Bang Theory',
        description: 'Nao veja dublado',
        imgUrl: ''
    },
    {
        id: '11',
        title: 'Breaking Bad',
        description: 'Quimica do Mal',
        imgUrl: ''
    }
];

module.exports = {
    moviesAndSeries
}